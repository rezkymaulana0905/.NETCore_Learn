abstract class Routes {
  static const initial = '/initial';
  static const login = '/login';
  static const home = '/home';
  static const employee = '/employee';
  static const guest = '/guest';
  static const supplier = '/supplier';
  static const contractor = '/contractor';
}
