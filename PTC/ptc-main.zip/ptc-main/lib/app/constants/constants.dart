export 'packages.dart';
export 'colors.dart';
export 'url.dart';

late double baseWidth;
late double baseHeight;