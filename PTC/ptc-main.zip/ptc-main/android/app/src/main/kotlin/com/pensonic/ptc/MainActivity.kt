package com.pensonic.ptc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
